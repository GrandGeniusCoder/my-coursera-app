import { ChakraProvider } from "@chakra-ui/react";
import Header from "../src/Header";
import LandingSection from "../src/LandingSection";
import ProjectsSection from "../src/ProjectsSection";

import Footer from "./Footer";
import { AlertProvider } from "./context/alertContext";
import Alert from "./Alert";

function App() {
  return (
    <ChakraProvider>
      <AlertProvider>
        <main>
          <Header />
          
          <ProjectsSection />
          <LandingSection />
          <Footer />
          <Alert />
        </main>
      </AlertProvider>
    </ChakraProvider>
  );
}

export default App;
